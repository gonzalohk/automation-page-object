# Automation test POM (Page Object Model)
Selenium can automate any application with some other elements. 
- Java
- Selenium
- TestNG
- Extent reports

This is a sample project structure to test the [https://the-internet.herokuapp.com/](https://the-internet.herokuapp.com/). 
